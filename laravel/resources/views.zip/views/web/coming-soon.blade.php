<!DOCTYPE html>
<html lang="en" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title>Coming Soon</title>
    </head>
    <body style="margin:0px;">
        <div style="width:100%;height:100vh;background:url({{ url('assets/iama-comingsoon.jpg') }});background-repeat:no-repeat;background-position:center;background-size:cover;">

        </div>
        <!-- <img src="iama-comingsoon.jpg" alt="Coming Soon" style="width:100%;height:100vh;"> -->
    </body>
</html>
