<!-- External JavaScripts
============================================= -->
<script type="text/javascript" src="{{ asset('laravel/resources/views/themes/batik-female/js/plugins.js') }}"></script>

<!-- Footer Scripts
============================================= -->
<script type="text/javascript" src="{{ asset('laravel/resources/views/themes/batik-female/js/functions.js') }}"></script>
